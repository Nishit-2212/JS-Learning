const loginAllowedFields = ["username","email","password","role"];




module.exports = { loginAllowedFields };